import React from 'react';
import { AlertTriangle, Terminal, Code2, Database, Mail, Phone, Send, User } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen relative p-4 md:p-8 flex flex-col items-center">
      <div className="scanline"></div>
      
      {/* Верхняя лента */}
      <div className="w-full h-8 bg-warning-stripes mb-8 flex items-center justify-center border-y-2 border-yellow-500 shadow-[0_0_15px_rgba(255,204,0,0.5)] z-10">
        <span className="bg-black px-4 text-yellow-500 font-bold uppercase tracking-widest text-sm border-x-2 border-yellow-500">Зона ограниченного доступа</span>
      </div>

      <div className="max-w-5xl w-full grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
        
        {/* Секция профиля */}
        <div className="col-span-1 border-2 border-yellow-500 bg-black/80 p-6 relative shadow-[0_0_20px_rgba(255,204,0,0.2)] flex flex-col items-center backdrop-blur-sm">
          {/* Уголки */}
          <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-red-500"></div>
          <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-red-500"></div>
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-red-500"></div>
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-red-500"></div>
          
          <div className="w-56 h-72 border-2 border-yellow-500 mb-6 flex items-center justify-center bg-zinc-900 overflow-hidden relative group">
            <div className="absolute inset-0 bg-yellow-500/20 group-hover:bg-transparent transition-all duration-500 z-10 pointer-events-none"></div>
            {/* Аватар */}
            <img 
              src="./profile.jpg" 
              alt="Кольчугин Роман" 
              className="w-full h-full object-cover mix-blend-luminosity group-hover:mix-blend-normal transition-all duration-500" 
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
                (e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden');
              }} 
            />
            <div className="hidden absolute inset-0 flex flex-col items-center justify-center text-yellow-500/50">
               <User size={64} className="mb-2" />
               <span className="text-xs">profile.jpg не найден</span>
            </div>
          </div>

          <h1 className="text-2xl font-bold text-white mb-2 text-center uppercase tracking-wider glitch">Кольчугин Роман</h1>
          <h2 className="text-red-500 font-bold mb-4 text-center animate-pulse">FULLSTACK РАЗРАБОТЧИК</h2>
          
          <div className="text-yellow-500/80 w-full text-sm mt-4">
            <p className="flex justify-between border-b border-yellow-500/30 pb-2 mb-3">
              <span>СТАТУС:</span> <span className="text-green-500 font-bold">АКТИВЕН</span>
            </p>
            <p className="flex justify-between border-b border-yellow-500/30 pb-2 mb-3">
              <span>ВОЗРАСТ:</span> <span>20 ЛЕТ</span>
            </p>
            <p className="flex justify-between border-b border-yellow-500/30 pb-2">
              <span>УРОВЕНЬ ДОСТУПА:</span> <span className="text-red-500 font-bold">ROOT</span>
            </p>
          </div>
        </div>

        {/* Секция Информации */}
        <div className="col-span-1 md:col-span-2 space-y-8">
          
          {/* Детали миссии */}
          <div className="border-2 border-yellow-500 bg-black/80 p-6 relative shadow-[0_0_15px_rgba(255,204,0,0.1)] backdrop-blur-sm">
             <div className="absolute top-0 left-0 w-2 h-2 bg-yellow-500"></div>
             <div className="absolute bottom-0 right-0 w-2 h-2 bg-yellow-500"></div>
             
             <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2 border-b-2 border-yellow-500/50 pb-2">
               <AlertTriangle className="text-red-500 animate-pulse" /> ДЕТАЛИ МИССИИ
             </h3>
             <div className="text-yellow-100/90 leading-relaxed font-mono">
               <p className="text-green-500 mb-2">&gt; Инициализация протокола знакомства...</p>
               <p className="text-green-500 mb-4">&gt; Загрузка данных субъекта... [УСПЕШНО]</p>
               <p className="text-justify border-l-2 border-yellow-500/50 pl-4 py-2 bg-yellow-500/5">
                 Специалист широкого профиля с опытом разработки масштабируемых систем. 
                 Способен эффективно работать как на стороне сервера, так и на клиенте.
                 Готов к выполнению сложных задач, устранению уязвимостей и проектированию надежной архитектуры баз данных и приложений.
               </p>
             </div>
          </div>

          {/* Технический арсенал */}
          <div className="border-2 border-yellow-500 bg-black/80 p-6 relative shadow-[0_0_15px_rgba(255,204,0,0.1)] backdrop-blur-sm">
             <div className="absolute top-0 right-0 w-2 h-2 bg-yellow-500"></div>
             <div className="absolute bottom-0 left-0 w-2 h-2 bg-yellow-500"></div>

             <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b-2 border-yellow-500/50 pb-2">
               <Terminal className="text-red-500" /> ТЕХНИЧЕСКИЙ АРСЕНАЛ
             </h3>
             <div className="space-y-6">
                <div className="group">
                  <div className="flex justify-between mb-2">
                    <span className="flex items-center gap-2 text-white"><Code2 size={18} className="text-yellow-500"/> React / Frontend</span>
                    <span className="text-green-500 text-xs tracking-widest border border-green-500/50 px-2 py-0.5 rounded-sm">РАЗВЕРНУТ</span>
                  </div>
                  <div className="h-3 w-full bg-zinc-900 border border-yellow-500/30 overflow-hidden">
                    <div className="h-full bg-yellow-500 w-[90%] shadow-[0_0_10px_rgba(255,204,0,1)] relative">
                      <div className="absolute inset-0 bg-white/20 w-full animate-[shimmer_2s_infinite]"></div>
                    </div>
                  </div>
                </div>
                
                <div className="group">
                  <div className="flex justify-between mb-2">
                    <span className="flex items-center gap-2 text-white"><Database size={18} className="text-yellow-500"/> C++ / Backend</span>
                    <span className="text-green-500 text-xs tracking-widest border border-green-500/50 px-2 py-0.5 rounded-sm">СТАБИЛЕН</span>
                  </div>
                  <div className="h-3 w-full bg-zinc-900 border border-yellow-500/30 overflow-hidden">
                    <div className="h-full bg-yellow-500 w-[85%] shadow-[0_0_10px_rgba(255,204,0,1)] relative">
                      <div className="absolute inset-0 bg-white/20 w-full animate-[shimmer_2s_infinite]"></div>
                    </div>
                  </div>
                </div>
                
                <div className="group">
                  <div className="flex justify-between mb-2">
                    <span className="flex items-center gap-2 text-white"><Terminal size={18} className="text-yellow-500"/> Python / Scripting</span>
                    <span className="text-green-500 text-xs tracking-widest border border-green-500/50 px-2 py-0.5 rounded-sm">В СЕТИ</span>
                  </div>
                  <div className="h-3 w-full bg-zinc-900 border border-yellow-500/30 overflow-hidden">
                    <div className="h-full bg-yellow-500 w-[80%] shadow-[0_0_10px_rgba(255,204,0,1)] relative">
                      <div className="absolute inset-0 bg-white/20 w-full animate-[shimmer_2s_infinite]"></div>
                    </div>
                  </div>
                </div>
             </div>
          </div>

          {/* Каналы связи */}
          <div className="border-2 border-yellow-500 bg-black/80 p-6 relative shadow-[0_0_15px_rgba(255,204,0,0.1)] backdrop-blur-sm">
             <div className="absolute top-0 left-0 w-2 h-2 bg-yellow-500"></div>
             <div className="absolute top-0 right-0 w-2 h-2 bg-yellow-500"></div>

             <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2 border-b-2 border-yellow-500/50 pb-2">
               <Phone className="text-red-500" /> КАНАЛЫ СВЯЗИ
             </h3>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <a href="tel:+79180094649" className="flex items-center gap-4 p-4 border border-yellow-500/30 hover:border-yellow-500 hover:bg-yellow-500/10 transition-all duration-300 group bg-black/50">
                  <div className="bg-yellow-500/10 p-2 border border-yellow-500/50 group-hover:border-yellow-500 group-hover:bg-yellow-500/20 transition-all">
                    <Phone className="text-red-500 group-hover:animate-pulse" size={24} />
                  </div>
                  <div>
                    <div className="text-xs text-yellow-500/50 mb-1">ГЛОБАЛЬНАЯ СЕТЬ</div>
                    <div className="text-white font-bold tracking-wider">+7 (918) 009-46-49</div>
                  </div>
                </a>
                
                <a href="mailto:fustroman23@mail.ru" className="flex items-center gap-4 p-4 border border-yellow-500/30 hover:border-yellow-500 hover:bg-yellow-500/10 transition-all duration-300 group bg-black/50 overflow-hidden">
                  <div className="bg-yellow-500/10 p-2 border border-yellow-500/50 group-hover:border-yellow-500 group-hover:bg-yellow-500/20 transition-all shrink-0">
                    <Mail className="text-red-500 group-hover:animate-pulse" size={24} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs text-yellow-500/50 mb-1">ЗАШИФРОВАННЫЙ EMAIL</div>
                    <div className="text-white font-bold tracking-wider truncate">fustroman23@mail.ru</div>
                  </div>
                </a>
                
                <a href="https://t.me/Rimich23" target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 border border-yellow-500/30 hover:border-yellow-500 hover:bg-yellow-500/10 transition-all duration-300 group bg-black/50 sm:col-span-2">
                  <div className="bg-yellow-500/10 p-2 border border-yellow-500/50 group-hover:border-yellow-500 group-hover:bg-yellow-500/20 transition-all">
                    <Send className="text-red-500 group-hover:animate-pulse" size={24} />
                  </div>
                  <div>
                    <div className="text-xs text-yellow-500/50 mb-1">ЗАЩИЩЕННЫЙ КАНАЛ TELEGRAM</div>
                    <div className="text-white font-bold tracking-wider text-lg">@Rimich23</div>
                  </div>
                </a>
             </div>
          </div>

        </div>
      </div>

      {/* Нижняя лента */}
      <div className="w-full h-8 bg-warning-stripes mt-12 flex items-center justify-center border-y-2 border-yellow-500 shadow-[0_0_15px_rgba(255,204,0,0.5)] z-10">
        <span className="bg-black px-4 text-yellow-500 font-bold uppercase tracking-widest text-sm border-x-2 border-yellow-500">Конец передачи</span>
      </div>
    </div>
  );
}

export default App;
